#include "Menu.h"
#include "StateManager.h"

GameMenu::GameMenu()
{
};


GameMenu::~GameMenu()
{
};

