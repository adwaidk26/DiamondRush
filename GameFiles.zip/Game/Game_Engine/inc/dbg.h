#pragma once
#include <string>

void debug(const std::string& message);